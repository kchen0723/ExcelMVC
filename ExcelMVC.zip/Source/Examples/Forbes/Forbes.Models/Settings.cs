﻿namespace Forbes.Models
{
    public class Settings
    {
        #region Properties

        public int UpdateIntervalSeconds { get; set; }

        #endregion Properties
    }
}
