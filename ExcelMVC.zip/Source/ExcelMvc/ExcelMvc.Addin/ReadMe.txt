ExcelMvc.Addin is an Excel XLOPER Addin with functions required for running ExcelMvc applications.
No change is required to this project.




