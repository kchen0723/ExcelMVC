﻿ExcelMVC - NuGet package
========================
Documentation can be found at the project site (https://sourceforge.net/projects/excelmvc/).

During installation of the ExcelMVC NuGet package the following changes were applied to your project:
1. Added a reference to <package>\lib\<targetFramework>\ExcelMvc.dll.
2. Added a file ExcelMvc.Addin.xll to your project.

Uninstalling
------------
* If the ExcelMVC NuGet package is uninstalled, the reference to ExcelMvc.dll and the file ExcelMvc.Addin.xll are removed.

