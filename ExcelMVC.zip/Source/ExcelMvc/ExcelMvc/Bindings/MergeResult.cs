﻿namespace ExcelMvc.Bindings
{
    internal struct MergeResult
    {
        #region Fields

        public bool Changed;
        public object Value;

        #endregion Fields
    }
}
