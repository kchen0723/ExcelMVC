﻿namespace ExcelMvc.Views
{
    #region Enumerations

    internal enum ViewOrientation
    {
        Portrait,
        Landscape
    }

    #endregion Enumerations
}
